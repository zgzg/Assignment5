package iss.java.mail;

import java.io.IOException;
import java.util.Properties;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;

public class IMail2014302580351 implements IMailService {
	/**
	 * ����session
	 */
	private transient Session session;
	
	private String user="15927072895";
	private String password="";

	@Override
	public void connect() throws MessagingException {

		// ��ʼ��propssd
		Properties prop =new Properties();
		prop.setProperty("mail.transport.protocol", "smtp");
		prop.setProperty("mail.store.protocol", "imap");	
		prop.setProperty("mail.imap.host", "imap.139.com");		
		prop.setProperty("mail.smtp.auth", "true");
		prop.setProperty("mail.imap.auth", "true");
		prop.setProperty("mail.smtp.host", "smtp.139.com");
//		prop.setProperty("mail.imap.ssl.enabled", "true");
		// ����session
		session = Session.getDefaultInstance(prop,new MailAuthenticator2014302580351(user,password));

	}

	@Override
	public void send(String recipient, String subject, Object content) throws MessagingException {
		
		// ����mime�����ʼ�
		MimeMessage message = new MimeMessage(session);
		// ���÷�����
		message.setFrom(new InternetAddress(user+"@139.com"));
		// �����ռ���
		message.setRecipient(RecipientType.TO, new InternetAddress(recipient));
		// ��������
		message.setSubject(subject);
		// �����ʼ�����
		message.setContent(content.toString(), "text/html;charset=utf-8");
		// ����
		Transport.send(message);

	}

	@Override
	public boolean listen() throws MessagingException {
		Store store = session.getStore();
		store.connect();
		Folder folder = store.getFolder("inbox");
		folder.open(Folder.READ_ONLY);
		if (folder.getNewMessageCount() > 0) {
//			folder.close(false);
//			store.close();
			return true;
		} else
//			folder.close(false);
//		store.close();
		return false;
	}

	@Override
	public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException {
		String content ="";
		Store store = session.getStore();
		store.connect(user,password);

		// ��������ڵ��ʼ���Folder������"ֻ��"��
		Folder folder = store.getFolder("inbox");
		folder.open(Folder.READ_ONLY);

		Message[] messages = folder.getMessages(1, 2);

		int mailCounts = messages.length;
		for (int i = 0; i < mailCounts; i++) {

			String subject1 = messages[i].getSubject();
			String from = (messages[i].getFrom()[0]).toString();
			System.out.println("�� " + (i + 1) + "���ʼ������⣺" + subject1);
			System.out.println("�� " + (i + 1) + "���ʼ��ķ����˵�ַ��" + from);
			content+=(messages[i].getContent()+"\n");
		}
		folder.close(false);
		store.close();
		return content;
	}
}
